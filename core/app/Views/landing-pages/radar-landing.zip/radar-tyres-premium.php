<!-- Page Title
============================================= -->
<!--<section id="page-title" class="page-title-dark page-title-right skrollable skrollable-between lozad-background" data-background-image="<?= base_url('assets/img/about-banner.webp'); ?>" style="padding: 300px 0;  background-size: cover!important; background-position: center center;" data-bottom-top="background-position:0px 440px;" data-top-bottom="background-position:0px -500px;">

    <div class="container clearfix">
        <h1>&nbsp;</h1>
        <span>&nbsp;</span>
    </div>

</section>--><!-- #page-title end -->


<section id="slider" class="slider-element swiper_wrapper home-slider main-slider-home full-width clearfix"  data-speed="650" data-loop="true">
	<div class="slider-parallax-inner">
		<div class="swiper-container swiper-parent">
			<div class="swiper-wrapper">
				<div class="swiper-slide dark slide-1" >
					<div class="container clearfix"></div>
				</div>
				<div class="swiper-slide dark slide-2" >
					<div class="container clearfix"></div>
				</div>
				<div class="swiper-slide dark slide-3" >
					<div class="container clearfix"></div>
				</div>
				<div class="swiper-slide dark slide-4" >
					<div class="container clearfix"></div>
				</div>
				<div class="swiper-slide dark slide-5" >
					<div class="container clearfix"></div>
				</div>
			</div>
			<div class="slider-arrow-left"><i class="icon-angle-left"></i></div>
			<div class="slider-arrow-right"><i class="icon-angle-right"></i></div>
			<!--<div class="slide-number"><div class="slide-number-current"></div><span>/</span><div class="slide-number-total"></div></div>-->
			<!--<div class="swiper-pagination"></div>
		    <a href="#" data-scrollto="#content" data-offset="70" class="dark one-page-arrow"><i class="icon-angle-down infinite animated fadeInDown"></i></a>-->
			
		</div>
	</div>
</section> <!--#page-title end -->
<!-- Content
============================================= -->
<section id="content">
<div class="content-wrap">
    <!--<div class="top-banner">
        
            <div class="rotating-slider">
               <ul class="slides">
                <li>
                    <div class="inner">
                        &nbsp;
                    </div>
                </li>
                <li>
                    <div class="inner">
                        &nbsp;
                    </div>
                </li><li>
                    <div class="inner">
                        &nbsp;
                    </div>
                </li>
                <li>
                    <div class="inner">
                        &nbsp;
                    </div>
                </li>
              </ul>
            </div>
    </div>-->
    
    <div class="nogimmick-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="large-heading">
                        <div class="large-heading--text">NO GIMMICKS</div>
                        <div class="large-heading--sub-text">We are changing the way you think about premium.</div>
                    </div>

                    <div class="text-content">
                        <div class="section-title text-center">
                            <div class="section-title--heading">the one-stop-shop</div>
                            <div class="section-title--text">
                                <p>Your customers are always looking to get the best tyres for their hard-earned money, but sometimes they've had to sacrifice on quality because of price. Not anymore. At Radar Tyres, we make premium tyres more accessible.</p>
                                <p>At Radar Tyres, we're not satisfied until your customers are happy. That's why we leverage advanced technology, best-in-class engineering and top-quality materials to create 2,000 sizes of premium tyres globally that offer superior handling, extended tread life and increased fuel efficiency – all for a fraction of the cost of other premium tyre brands.</p> 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </div>  

    <div class="icons-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="icons-widget">
                        <div class="text-content text-center">
                            <div class="section-title">
                                <div class="section-title--heading">sized for all your needs</div>
                            </div>
                        </div>
                        <div class="icons">
                            <div class="icon">
                                <div class="icon--image">
                                    <img src="<?=base_url('assets/img/landing-pages/9/Icon_Car.webp')?>" alt="">
                                </div>
                                <div class="icon--heading">CAR / CUV / SUV</div>
                                <div class="icon--decsription">12 MODELS - 533 SIZES</div>
                            </div>
                            <div class="icon">
                                <div class="icon--image">
                                    <img src="<?=base_url('assets/img/landing-pages/9/Icon_SUV.webp')?>" alt="">
                                </div>
                                <div class="icon--heading">SUV / 4X4</div>
                                <div class="icon--decsription">6 MODELS - 159 SIZES</div>
                            </div>
                            <div class="icon">
                                <div class="icon--image">
                                    <img src="<?=base_url('assets/img/landing-pages/9/Icon_Van.webp')?>" alt="">
                                </div>
                                <div class="icon--heading">VAN / TRAILER </div>
                                <div class="icon--decsription">5 MODELS - 78 SIZES</div>
                            </div>
                            <div class="icon">
                                <div class="icon--image">
                                    <img src="<?=base_url('assets/img/landing-pages/9/Icon_Truck.webp')?>" alt="">
                                </div>
                                <div class="icon--heading">TRUCK / BUS RADIALS</div>
                                <div class="icon--decsription">6 MODELS - 13 SIZES</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div id="cta-red" class="section-red">
        <div class="container">
            <div class="row flex-columns">
                <div class="flex-col text">tell us which sizes you need</div>
                <div class="flex-col"><a href="#contact-section" class="button-white-text-black">contact us</a></div>
            </div>
        </div>
    </div>
    
    <div id="floating-button" class="fixed top right">
        <a href="#contact-section" class="contact-button">CONTACT US</a>
    </div>
    
    <div id="driving-section" class="section-two-col">
        <div class="container">
            <div class="row flex-columns">
                <div class="flex-col image"><img src='<?= base_url("assets/img/landing-pages/9/DrivingFutureSection_Tire.webp")?>' /></div>
                <div class="flex-col text">
                    <div class="section-title">
                        <div class="section-title--heading">DRIVING THE FUTURE OF THE INDUSTRY</div>
                        <div class="section-title--text">
                            We have an unrelenting passion to improve the quality of drivers' time on the road, so we invest in cutting-edge R&D and work with legendary Italian designer Giorgetto Guigiaro of GFG Style - awarded Designer of the Century for his iconic automotive designs including the Maserati, Lotus Esprit, DeLorean, Aston Martin, BMW, Bugatti, Ferrari, Lotus and many more iconic vehicles.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div id="engineering-section" class="section-two-col">
        <div class="container">
            <div class="row flex-columns">
                <div class="flex-col text">
                    <div class="section-title">
                        <div class="section-title--heading">ENGINEERING FOR PERFORMANCE</div>
                        <div class="section-title--text">
                    We will not rest until we've given every customer the very best, so Radar Tyres are perfectly crafted and rigorously tested to meet or beat other premium tyres in term of grip, handling, noise, stopping distance and fuel efficiency.
                    </div>
                    </div>
                </div>
                <div class="flex-col image"><img src='<?= base_url("assets/img/landing-pages/9/Icon_Stars.webp")?>' /></div>
            </div>
        </div>
    </div>
    
    <div id="quality-section" class="section-two-col">
        <div class="flex-columns">
            <div class="flex-col image"><img src="<?= base_url('assets/img/landing-pages/9/QualitySection_Tire.webp')?>" /></div>
            <div class="flex-col text">
                    <div class="section-title">
                        <div class="section-title--heading">QUALITY YOU<br>CAN COUNT ON</div>
                        <div class="section-title--text">
                    You need partners who bring you repeat business, not repeat headaches. That’s why Radar Tyres feature reinforced sidewalls, special tread compounds and lateral ties for even wear and extended tread life - all backed by our extensive quality control and product testing.
                        </div>
                    </div>
                </div>
        </div>
    </div>
    
    <div id="fitting-seciton" class="section-two-col">
        <div class="container">
            <div class="flex-columns">
                <div class="flex-col text">
                    <div class="section-title">
                        <div class="section-title--heading">FITTING EVERY DRIVER</div>
                        <div class="section-title--text">
                    We know you have better things to do than manage multiple suppliers, so we give you everything you need right here. We offer 2,000 tyre sizes globally to support all types of vehicles in nearly any type of terrain.
                    </div>
                    </div>
                </div>
                <div class="flex-col image"><img src='<?= base_url("assets/img/landing-pages/10/rp-uk-dimax-r8-plus.webp")?>' /></div>
            </div>
        </div>
    </div>
    
    <div id="protecting-section" class="section-two-col">
        <div class="container">
            <div class="row flex-columns">
                <div class="flex-col image"><img src='<?= base_url("assets/img/landing-pages/9/Icon_CO2.webp")?>' /></div>
                <div class="flex-col text">
                    <div class="section-title">
                        <div class="section-title--heading">PROTECTING OUR FUTURE</div>
                        <div class="section-title--text">
                    We don’t just envision a bright future for the world ahead, we’re committed to making it happen. That’s why we were the first in the industry to have a “manufactured carbon neutral” tyre brand back in 2013, and we continue to invest in sustainable practices and more.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div id="partnering-seciton" class="section-red">
        <div class="container">
            <div class="row flex-columns">
                <div class="flex-col text--heading">PARTNERING<br>FOR SUCCESS</div>
                <div class="flex-col text--body">We’re here to set you up for success with sales tools and point of purchase materials, front and back of house employee training, incentives and dedicated support for your entire team, so you have what you need to confidently help every customer, every time.</div>
            </div>
        </div>
    </div>
    
    <div id="contact-section" class="section-col">
        <div class="container">
            <div class="flex-columns">
                <div class="flex-col ">
                    <div class="section-title extrafont x-large underline">
                        <h2 class="section-title--heading">contact us</h2>
                    </div>
                </div>
                <div class="flex-col flex-col--full">
                    <div class="row clearfix">
                    <div class="col-12 offset-0 col-sm-10 offset-sm-1">
                        <form action="<?= base_url('redartires-premium/submit')?>" id="contact-form" method="post" class="omniform" >
                            <div class="alert alert-danger error" role="alert"></div>
                            <div class="row">
                                <div class="col-12 col-sm-6 form-group">
                                    <input type="text" name="name" id="name" class="form-control required" placeholder="NAME*">
                                </div>
                                <div class="col-12 col-sm-6 form-group">
                                    <input type="text" name="companyname" id="companyname" class="form-control required" placeholder="COMPANY NAME*">
                                </div>
                                <div class="col-12 col-sm-6 form-group">
                                    <input type="email" name="email" id="email" class="form-control required" placeholder="EMAIL*">
                                </div>
                                <div class="col-12 col-sm-6 form-group">
                                    <input type="text" name="mobile" id="mobile" class="form-control" placeholder="PHONE">
                                </div>
                                <div class="col-12 form-group">
                                    <input type="text" name="addresslocation" id="addresslocation" class="form-control" placeholder="ADDRESS/LOCATION">
                                </div>
                                <div class="col-12 form-group">
                                    <textarea name="message" id="message" class="form-control valid" cols="30" rows="4" placeholder="ENQUIRY*"></textarea>
                                </div>
                            </div>
                            <div class="row formfooter clearfix">
                                <div class="col-7">
                                    <div class="form-inline">
                                        <div class="form-group mb-2">
                                            <label>I AM A</label>
                                        </div>
                                        <div class="form-group mx-sm-3 mb-2">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" id="defaultCheck1" name="wholeseller">
                                                <label class="form-check-label" for="defaultCheck1">WHOLESELLER</label>
                                            </div>
                                        </div>
                                        <div class="form-group mx-sm-3 mb-2">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck2" name="retailer">
                                                <label class="form-check-label" for="defaultCheck2">RETAILER</label>
                                            </div>
                                        </div>
                                        <div class="form-group mx-sm-3 mb-2">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck3" name="consumer">
                                                <label class="form-check-label" for="defaultCheck3">CONSUMER</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-5">
                                    <div class="form-inline">
                                        <div class="form-group mx-sm-3 mb-2">
                                            <label class="req-field-text"><i>*Required Fields</i></label>
                                        </div>
                                        <div class="form-group mb-2">
                                            <button type="submit" class="btn btn-primary mb-2 submit">SUBMIT</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="alert alert-success result" role="alert"></div>
                            <div class="clearfix"></div>
                            <div class="col_full hidden">
                                <input type="text" id="phone" name="phone" value="" class="sm-form-control" />
                                <input type="hidden" id="current_page" name="current_page" value="<?= current_url(); ?>">
                                <input type="text" id="g-recaptcha" name="g-recaptcha" value="" />
                                <input type="text" id="g-recaptcha-action" name="g-recaptcha-action" value="" />
                            </div>
                        </form>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>
</div><!-- #content-wrap end -->
</section><!-- #content end -->
<style type="text/css">

/*
COMMON STYLES
*/
    .content-wrap{background-color: #000000;}
    /*  section-title  */
    .section-title{
            font-family: 'Montserrat', sans-serif;
            line-height: 1.3;
        }
        .section-title--heading{
            font-weight:800;
            font-size:25px;
            text-transform:uppercase;
        }
        .section-title--text{
            font-weight:400;
            font-size:18px;
            margin-top: 20px;
        }
        
        .section-title--text p{
            margin-bottom: 15px;
            line-height: 1.3 !important;
            text-align: center !important;
        }
        
        .section-title--text p:last-child{
            margin-bottom: 0;
        }
        
        
        .section-title.extrafont .section-title--heading{
            font-family: 'Gobold High Bold'!important;
            font-weight: 400;
            font-style: normal;
            color: #fff;
        }
        
        .section-title.x-large .section-title--heading{
            font-size:130px;
        }
        .section-title.underline .section-title--heading:after{
            content: " ";
            margin-top: 30px;
            margin-bottom: 50px;
            width: 100px;
            height: 2px;
            background-color: #DA2224;
            display: block;
            left: 50%;
            position: relative;
            transform: translateX(-50%);
        }
        
        /*   header     */
        #header.full-header #logo.custom-logo img {
          width: 180px;
          height:auto;
        }
          @media only screen and (max-width: 922px){
                #header.full-header #logo.custom-logo img {
                  width: 157px;
                  height: auto;
                }
            }
        @media (max-width: 922px){
            #logo a.retina-logo {
              padding-top: 18px;
            }

            #header.full-header #logo.custom-logo img {
              margin-top: 0;
            }
            #logo {
              height: 59px;
            }
            .custom-logo {
              position: relative;
              top: 0;
            }
            .home-link.for-small-too {
              margin-top: -33px;
            }
            #top-search a {
                margin-top: 25px !important;
            }
        }
        /*  flex-section  */
        .flex-columns{
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: row;
            flex-wrap: wrap;
        }
        
        

        /*  two col      */
/*
COMMON STYLES
*/

/*TOP SECTION*/

/*Slider*/
#header.transparent-header + #slider {
  top: -10px;
  margin-bottom: -10px;
}
.swiper_wrapper .swiper-container{height:auto!important;}
.slider-element.swiper_wrapper{height: 50vh !important;background: #000;}
.swiper-slide{ height: 50vh!important; }
.swiper-slide{ background-color: #000; background-size:  50% !important; }

.swiper-slide.slide-1{ background-image: url('<?=base_url("assets/img/landing-pages/10/slides/rp-uk-banner-renegade-x.webp")?>');?>); }
.swiper-slide.slide-2{ background-image: url('<?=base_url("assets/img/landing-pages/10/slides/rp-uk-banner--renegade-rt-plus.webp")?>');; }
.swiper-slide.slide-3{ background-image: url('<?=base_url("assets/img/landing-pages/10/slides/rp-uk-banner--dimax-r8-plus.webp")?>');; }
.swiper-slide.slide-4{ background-image: url('<?=base_url("assets/img/landing-pages/10/slides/rp-uk-banner--dimax-sport.webp")?>');; }
.swiper-slide.slide-5{ background-image: url('<?=base_url("assets/img/landing-pages/10/slides/rp-uk-banner--dimax-classic.webp")?>');; }

@media screen and (max-width: 991.98px){
    .swiper-slide {
      background-color: #000;
      background-size: 80% !important;
    }
}

@media screen and (max-width: 510px){
    .slider-element.swiper_wrapper,.swiper_wrapper .swiper-slide {
      height: 30vh !important;
    }
}
/*Slider*/
    .top-banner{
        padding-top:0px;
    }
    .rotating-slider{
        /*width:auto!important;
        height:auto!important;*/
        margin-top:0;
        overflow:hidden;
        margin-left:auto;
        margin-right:auto;
    }
    .rotating-slider ul.slides li{
          clip-path: none!important;
          background-repeat:no-repeat!important;
          background-size:contain!important;
    }
    .rotating-slider ul.slides li:nth-of-type(1) { background: url('<?=base_url("assets/img/landing-pages/9/slides/OMNI -Landing-Page-Hero-1.webp")?>'); }
    .rotating-slider ul.slides li:nth-of-type(2) { background: url('<?=base_url("assets/img/landing-pages/9/slides/OMNI -Landing-Page-Hero-2.webp")?>'); }
    .rotating-slider ul.slides li:nth-of-type(3) { background: url('<?=base_url("assets/img/landing-pages/9/slides/OMNI -Landing-Page-Hero-3.webp")?>'); }
    .rotating-slider ul.slides li:nth-of-type(4) { background: url('<?=base_url("assets/img/landing-pages/9/slides/OMNI -Landing-Page-Hero-4.webp")?>'); }
    @media screen and (max-width:768px) {
        .top-banner{ padding-top:30px; }
        .rotating-slider{margin-bottom:0;}
    }
    @media screen and (max-width:510px) {
        .top-banner{ padding-top:10px; }
        .rotating-slider{margin-bottom:0;}
        .rotating-slider ul.slides li:nth-of-type(1) { background: url('<?=base_url("assets/img/landing-pages/9/slides/OMNI -Landing-Page-Hero-1-m.webp")?>'); }
        .rotating-slider ul.slides li:nth-of-type(2) { background: url('<?=base_url("assets/img/landing-pages/9/slides/OMNI -Landing-Page-Hero-2-m.webp")?>'); }
        .rotating-slider ul.slides li:nth-of-type(3) { background: url('<?=base_url("assets/img/landing-pages/9/slides/OMNI -Landing-Page-Hero-3-m.webp")?>'); }
        .rotating-slider ul.slides li:nth-of-type(4) { background: url('<?=base_url("assets/img/landing-pages/9/slides/OMNI -Landing-Page-Hero-4-m.webp")?>'); }
    }
/*TOP SECTION*/

    .nogimmick-section, .top-banner,.icons-section{
        background-color: #000000;
        color: #fff;
    }
    .large-heading{
        text-align: center;
    }
    .large-heading:after{
        content: " ";
        margin-top: 30px;
        margin-bottom: 50px;
        width: 166px;
        height: 3px;
        background-color: #DA2224;
        display: block;
        left: 50%;
        position: relative;
        transform: translateX(-50%);
    }
    .large-heading .large-heading--text{
        font-family: 'Gobold High Bold' !important;
        font-size: 264px;
        font-weight: 400;
        font-style: normal;
        color: #DA2224;
        line-height: 1.2;
    }
    .large-heading .large-heading--sub-text{
        font-family: 'Montserrat', sans-serif;
        font-weight: 600;
        font-size: 18px;
        text-transform: uppercase;
        line-height: 1.2;
        letter-spacing: 5px;
    }
    .nogimmick-section{
        margin-top:-10px;
    }
    @media (min-width: 768px) and (max-width: 991.98px){
        .large-heading .large-heading--text {font-size: 190px;}
        .large-heading .large-heading--sub-text {  font-size: 14px; letter-spacing: 2px; }
    }
    @media screen and (max-width:510px) {
        .large-heading .large-heading--text {font-size: 100px;}
        .large-heading .large-heading--sub-text {  font-size: 12px; letter-spacing: 3px; }
        
        .nogimmick-section{
            margin-top:-10px;
        }
    }

/* 
ICON SECTION
*/
    .icons-section{
        background-color: #000;
    }
    .icons-section .icons-widget{
        padding: 60px 0;
        margin:60px 0;
        border-top:3px solid #DA2224;
        border-bottom:3px solid #DA2224;
    }
    .icons-section .icons{
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        align-items: center;
        margin:25px -20px 0;
    }
    .icons-section .icons .icon{
        font-family: 'Montserrat', sans-serif !important;
        line-height: 1.3;
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        border-right:3px solid #DA2224;
        width: 19%;
        margin: 0 10px;
        padding: 0 10px;
        text-align:center;
    }
    .icons-section .icons .icon .icon--heading,
    .icons-section .icons .icon .icon--decsription 
    {font-family: 'Montserrat', sans-serif !important;}
    .icons-section .icons .icon:last-child{
        border-right:none;
    }
    .icons-section .icons .icon .icon--image{
        max-width: 160px;
        margin-bottom:10px;
    }
    .icons-section .icons .icon .icon--heading{
        font-size: 15px;
        font-weight: 600;
    }
    .icons-section .icons .icon .icon--decsription{
        font-size: 15px;
        font-weight: 300;
    }
    @media screen and (max-width:768px) {
        .icons-section .icons{margin-top:40px;}
        .icons-section .icons .icon{
            width: 40%;
        }
        .icons-section .icons .icon:nth-child(2n){
            border-right:none;
        }
        .icons-section .icons .icon:nth-child(1){
            margin-bottom:25px;
        }
        .icons-section .icons .icon:nth-child(2){
            margin-bottom:25px;
        }
    }
    @media screen and (max-width:510px) {
        .icons-section .icons .icon{
            width: 90%;
        }
        .icons-section .icons .icon:nth-child(n){
            border-right:none;
            margin-bottom: 35px;
        }
        .icons-section .icons .icon:nth-child(4){
            margin-bottom:0;
        }
    }
/* 
ICON SECTION
*/

/* CTA SECTION RED */
    #cta-red.section-red{
        background-color: #DA2224;
        padding: 15px 0;
        color: #fff;
        text-transform:uppercase;
    }

    #cta-red.section-red .flex-columns .flex-col{
        margin-right:15px;
    }
    #cta-red.section-red .flex-columns .flex-col:last-child{
        margin-right:0;
    }
    #cta-red.section-red .button-white-text-black{
        display: inline-block;
        padding: 8px 15px;
        background-color:#fff;
        color:#000;
        font-family: 'Montserrat', sans-serif;
        font-weight:800;
        font-size:25px;
    }
    #cta-red.section-red .text{
        font-family: 'Montserrat', sans-serif;
        font-weight:800;
        font-size:25px;
    }
    @media screen and (max-width:768px) {
        
    }
    @media screen and (max-width:510px) {
        #cta-red.section-red { padding: 30px 0; }
        #cta-red.section-red .flex-columns{ flex-direction: column; }
        #cta-red.section-red .flex-columns .flex-col { margin-right: 15px;  margin-left: 15px; text-align: center;  line-height: 1.3; margin-bottom: 10px; }
        #cta-red.section-red .flex-columns .flex-col:last-child {margin-bottom: 0; }
    }
/* CTA SECTION RED */


/*FLOATING BUTTON*/

    #floating-button.fixed{
        position:fixed;
        z-index:1;
    }
    #floating-button.top{
        top: 90px;
    }
    
    #floating-button.right{
        right: 30px;
    }
    #floating-button a.contact-button{
        font-family: 'Montserrat', sans-serif;
        font-weight:600;
        display: inline-block;
        background-color: #000;
        border: solid 3px #DA2224;
        text-transform: uppercase;
        padding: 12px 15px;
        color: white;
        font-weight: 600;
        font-size: 18px;
    }
    
    @media screen and (max-width:510px) {
        #floating-button{ display: none;}
        #floating-button.top{ top: 90px; }
        #floating-button a.contact-button { padding: 8px 12px; font-size: 16px; }
    }
    
/*FLOATING BUTTON*/
/*DRIVING SECITON*/
    #driving-section.section-two-col{
        background-color: #000;
        padding: 55px 0 0;
        color: #fff;
    } 

    #driving-section.section-two-col .flex-columns .flex-col{
        width:auto;
        padding-right:60px;
    }
    #driving-section.section-two-col .flex-columns .flex-col:last-child{
        margin-right:0;
    }
    #driving-section.section-two-col .image{
        display: block;
        max-width:60%;
    }
    #driving-section.section-two-col .text{
        display: block;
        max-width:40%;
    }
    #driving-section.section-two-col .image img{
        max-width:100%;
    }
    @media screen and (max-width:768px) {
       #driving-section.section-two-col { padding: 60px 0 60px; }
       #driving-section.section-two-col .flex-columns {  flex-direction: column; flex-wrap: wrap; } 
       #driving-section.section-two-col .flex-columns .flex-col { max-width: 70%;padding-right: 0;margin-bottom: 35px; text-align: center; }
       #driving-section.section-two-col .flex-columns .flex-col:last-child { margin-bottom: 0; }
    }
    @media screen and (max-width:510px) {
       #driving-section.section-two-col { padding: 40px 0; }
    }
/*DRIVING SECITON*/
/*ENGINEERING SECTION*/
    #engineering-section.section-two-col{
        background-color: #333333;
        padding: 152px 0;
        color: #fff;
    }
    #engineering-section.section-two-col .flex-columns{
        margin-left:-30px;
        margin-right:-30px;
    }
    #engineering-section.section-two-col .flex-columns .flex-col{
        max-width:50%;
        width:auto;
        margin-left:30px;
        margin-right:30px;
    }
    #engineering-section.section-two-col .image{
        display: block;
        max-width:50%;
    }
    #engineering-section.section-two-col .image img{
        max-width:100%;
    }
    #engineering-section.section-two-col .text{
        font-family: 'Montserrat', sans-serif;
        line-height: 1.3;
        padding-right: 60px;
    }
    @media screen and (max-width:768px) {
       #engineering-section.section-two-col { padding: 60px 0 60px; }
       #engineering-section.section-two-col .flex-columns {  flex-direction: column-reverse; flex-wrap: wrap; } 
       #engineering-section.section-two-col .flex-columns .flex-col { max-width: 70%;padding-right: 0;margin-bottom: 35px; text-align: center; }
       #engineering-section.section-two-col .flex-columns .flex-col:first-child { margin-bottom: 0; }
    }
    @media screen and (max-width:510px) {
       #engineering-section.section-two-col { padding: 40px 0; }
    }
/*ENGINEERING SECTION*/
/*QUALITY SECITON*/
    #quality-section.section-two-col{
        background-color: #000;
        padding: 80px 0 0;
        color: #fff;
    }
    #quality-section.section-two-col .flex-columns .flex-col{
        max-width:50%;
        width:auto;
    }
    #quality-section.section-two-col .image{
        display: block;
        max-width:50%;
    }
    #quality-section.section-two-col .image img{
        max-width:100%;
    }
    #quality-section.section-two-col .text{
        width: 35% !important;
        margin-right: 15%;
    }
    @media screen and (max-width:768px) {
       #quality-section.section-two-col { padding: 60px 0 0; }
       #quality-section.section-two-col .flex-columns {  flex-direction: column-reverse; flex-wrap: wrap; } 
       #quality-section.section-two-col .flex-columns .flex-col { max-width: 100%;padding-right: 0;margin-bottom: 0;margin-bottom: 35px; text-align: center; }
       #quality-section.section-two-col .flex-columns .text { max-width: 70%;width:70%!important; margin-right:30px; margin-left: 30px; text-align: center; }
       #quality-section.section-two-col .flex-columns .flex-col:first-child { margin-bottom: 0; }
    }
    @media screen and (max-width:510px) {
       #quality-section.section-two-col { padding: 40px 0 0; }
    }
/*QUALITY SECITON*/
/*FITTING SECTION*/
    #fitting-seciton.section-two-col{
        background-color: #333333;
        padding: 0;
        color: #fff;
    }
    
    #fitting-seciton.section-two-col .flex-columns .flex-col{
        max-width: 50%;
        width: auto;
        padding-right:60px;
    }
    
    #fitting-seciton.section-two-col .flex-columns .flex-col:last-child{
        padding-right:0;
    }
    
    #fitting-seciton.section-two-col .image img{
        max-width:100%;
    }
    @media screen and (max-width:768px) {
        #fitting-seciton.section-two-col { padding: 60px 0 0; }
        #fitting-seciton.section-two-col .flex-columns {  flex-direction: column; flex-wrap: wrap; } 
        #fitting-seciton.section-two-col .flex-columns .flex-col { max-width: 70%;padding-right: 0;}
        #fitting-seciton.section-two-col .flex-columns .text { text-align:center; }
    }
    @media screen and (max-width:510px) {
       #fitting-seciton.section-two-col { padding: 40px 0 0; }
    }
/*FITTING SECTION*/
/*PROTECTING SECTION*/
    #protecting-section.section-two-col{
        background-color: #000;
        padding: 189px 0;
        color: #fff;
    }
    #protecting-section.section-two-col .flex-columns .flex-col{
        max-width:50%;
        width:auto;
        padding-right:60px;
    }
    #protecting-section.section-two-col .flex-columns .flex-col:last-child{
        padding-left: 30px;
        padding-right:0;
    }
    #protecting-section.section-two-col .image{
        display: block;
        max-width:50%;
    }
    #protecting-section.section-two-col .image img{
        max-width:100%;
    }
    @media screen and (max-width:768px) {
        #protecting-section.section-two-col { padding: 60px 0; }
        #protecting-section.section-two-col .flex-columns {  flex-direction: column; flex-wrap: wrap; } 
        #protecting-section.section-two-col .flex-columns .flex-col { max-width: 70%; padding: 0;margin-bottom: 35px; padding-right:0;}
        #protecting-section.section-two-col .flex-columns .flex-col:last-child { margin-bottom: 0;}
        #protecting-section.section-two-col .flex-columns .text { text-align:center; }
    }
    @media screen and (max-width:510px) {
       #protecting-section.section-two-col { padding: 40px 0; }
    }
/*PROTECTING SECTION*/
/*CONTACT-SECTION*/
    #contact-section.section-col{
        background-color: #000000;
        padding: 100px 0 80px;
        color: #fff;
    }
    #contact-section.section-col .flex-columns{
        margin-left:-30px;
        margin-right:-30px;
    }
    #contact-section.section-col .flex-columns .flex-col{
        max-width:50%;
        width:auto;
        margin-left:30px;
        margin-right:30px;
    }
    #contact-section.section-col .flex-columns .flex-col.flex-col--full{
        max-width:100%;
        width:auto;}

    
    #contact-section.section-col form{
        font-family: 'Montserrat', sans-serif;
        line-height: 1.3;
        text-align:center;
    }
    
    #contact-section.section-col form .formfooter .col-7 {
      padding-top: 16px;
    }
    #contact-section.section-col form .formfooter .col-5 {
      justify-content: flex-end;
      display: flex;
    }

    
    #contact-section.section-col form input,
    #contact-section.section-col form textarea,
    #contact-section.section-col form label
    {
        font-weight:600;
    }
    #contact-section.section-col form input,
    #contact-section.section-col form textarea{
        color:#000;
    }
    #contact-section.section-col form label
    {
        color:white;
    }
    #contact-section.section-col form label.req-field-text{
        font-weight:300;
        text-transform: none;
    }
    
    #contact-section.section-col form .formfooter button {
      background-color: #DA2224;
      border: none;
      border-radius: 0;
      font-weight: bold;
      padding: 10px 20px;
    }
    
    @media screen and (max-width:768px) {
        #contact-section.section-two-col { padding: 60px 0; }
       .section-title.x-large .section-title--heading { font-size: 90px; }
       #contact-section.section-col form {margin-bottom: 0; }
       #contact-section.section-col .flex-columns .flex-col{ max-width:100%; }
       #contact-section.section-col .flex-columns .flex-col .formfooter .col-5 .form-inline{ flex-wrap: initial; }
       #contact-section.section-col form label.req-field-text { font-size: 10px; }
    }
    
    @media screen and (max-width:510px) {
        #contact-section.section-two-col { padding: 40px 0; }
        .section-title.x-large .section-title--heading { font-size: 70px; }
        #contact-section.section-col .flex-columns .flex-col .formfooter .col-7 .form-inline{ flex-flow: column wrap; justify-content: flex-start; align-items: flex-start; }
        #contact-section.section-col .flex-columns .flex-col .formfooter .col-5 .form-inline{ flex-flow: column wrap;}
    }
/*CONTACT-SECTION*/
/*PARTNERING SECTION*/
    #partnering-seciton.section-red{
        background-color: #DA2224;
        padding: 167px 0;
        color: #fff;
    }
    #partnering-seciton.section-red .flex-columns .flex-col{
        margin-right:60px;
        max-width:50%;
    }
    #partnering-seciton.section-red .flex-columns .flex-col:last-child{
        margin-right:0;
    }
    #partnering-seciton.section-red .text--heading{
        font-family: 'Montserrat', sans-serif;
        font-weight:800;
        font-size:25px;
        text-transform:uppercase;
        line-height: 1.3;
    }
    #partnering-seciton.section-red .text--body{
        font-family: 'Montserrat', sans-serif;
        font-weight:400;
        font-size:18px;
        line-height: 1.3;
    }
    @media screen and (max-width:768px) {
        #partnering-seciton.section-red { padding: 60px 0; }
        #partnering-seciton.section-red .flex-columns {  flex-direction: column; flex-wrap: wrap; } 
        #partnering-seciton.section-red .flex-columns .flex-col { max-width: 70%; padding: 0; margin:0;margin-bottom: 25px;}
        #partnering-seciton.section-red .flex-columns .flex-col:last-child { margin-bottom: 0;}
        #partnering-seciton.section-red .flex-columns .text { text-align:center; }
        #partnering-seciton.section-red .text--body {text-align: center;}
    }
    @media screen and (max-width:510px) {
       #partnering-seciton.section-red { padding: 40px 0; }
    }
/*PARTNERING SECTION*/
    
</style>                