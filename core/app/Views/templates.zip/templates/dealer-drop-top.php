<div class="header-custom-link with-dropdown for-small-too" >
    <a href="#">Dealer Locator</a>
    <ul class="hcl--dropdown">
        <li><a href="https://radartyres.com/eu#dealer-locator">Europe</a></li>
        <li><a href="https://radartires.com/us#dealer-locator">North America</a></li>
    </ul>
</div>